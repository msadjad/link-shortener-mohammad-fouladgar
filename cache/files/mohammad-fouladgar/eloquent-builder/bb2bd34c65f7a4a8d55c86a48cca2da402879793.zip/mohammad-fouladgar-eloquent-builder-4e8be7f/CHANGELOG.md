## 2.2.2 - 2020-09-05
 - Fix ignoring zero values filters (#78)

## 2.2.1 - 2020-07-13
 - Fix nested array in ignoring filters

## 2.2.0 - 2020-03-04
 - Add support for Laravel 7

## 2.1.0:
 - Add an artisan command to make filter[s]

## 2.0.0:
- Add support for Domain/Module
- Add support for Eloquent Model Instance

## 1.1.0:
 - Add support for Laravel 6

## 1.0.0:
 - release v1.0.0
