<?php

namespace Fouladgar\EloquentBuilder\Exceptions;

use Exception;

class NotFoundFilterException extends Exception
{
}
